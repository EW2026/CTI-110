from decimal import Decimal, ROUND_HALF_UP

def emp_variables():
    fName = char_valid("Enter employee first name: ")
    lName = char_valid("Enter employee last name: ")
    email = input("Enter employee email: ")
    pay = float_valid("Enter employee pay: ")
    return fName, lName, pay, email


def hours_variables():
    hours = float_valid("Enter employee hours not including holiday hours: ")
    return hours


def float_valid(prompt, optional=False):
    while True:
        value = input(prompt)

        if optional and value == "":
            return None

        try:
            return float(value)
        except ValueError:
            print("Invalid entry, please enter valid number EX (00.00)")


def int_valid(prompt, optional=False):
    while True:
        value = input(prompt)

        if optional and value == "":
            return None

        try:
            return int(value)
        except ValueError:
            print("Invalid entry, please enter valid number EX (00)")


def char_valid(prompt):
    while True:
        char = input(prompt)

        if char.replace(" ", "").replace("-", "").replace("'", "").isalpha():
            return char

        print("Invalid entry please enter valid name")


def hday_hours(PAY, pay):
    num_holidays = int_valid("Enter number of holidays worked: ")

    if num_holidays > 0:
        holiday_hours = float_valid("Enter number of hours worked during holidays: ")
        holiday_rate = PAY * pay
        holiday_pay = holiday_rate * holiday_hours
        return holiday_hours, holiday_pay
    else:
        return 0, 0


def ot_pay(pay, PAY, hours):
    if hours > 40:
        overtime = hours - 40
        overtime_rate = pay * PAY
        overtime_pay = overtime * overtime_rate
        return overtime, overtime_pay
    else:
        return 0, 0


def gross_pay(pay, hours, overtime_pay, overtime, holiday_pay, holiday_hours,):

    regular_hours = min(hours, 40)
    gross = regular_hours * pay

    if overtime > 0:
        gross += overtime_pay

    if holiday_hours > 0:
        gross += holiday_pay

    gross = Decimal(str(gross))
    gross = gross.quantize(Decimal("0.01"), rounding = ROUND_HALF_UP)
    return gross





    
    

