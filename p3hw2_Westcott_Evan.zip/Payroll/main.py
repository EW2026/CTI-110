# Evan Westcott
# 20260310
# P3HW2
# Payroll Calculator with Database




# Imports
    # Imports the table objects
from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey

from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy.orm import sessionmaker, relationship

from sqlalchemy.exc import IntegrityError

import employee_functions


# Create Database

engine = create_engine("sqlite:///employees.db", echo=False)
Base = declarative_base()
Session = sessionmaker(bind=engine)
session = Session()


# Create Models (tables)

class Employee(Base):
    __tablename__ = "employees"
    id = Column(Integer, primary_key=True)
    fName = Column(String, nullable=False)
    lName = Column(String, nullable=False)
    email = Column(String, nullable=False, unique=True)
    pay = Column(Float, nullable=False)
    
    paychecks = relationship("Paycheck", back_populates="employee", cascade="all, delete-orphan")

class Paycheck(Base):
    __tablename__ = "paychecks"
    id = Column(Integer, primary_key=True)
    hours = Column(Float, nullable=False)
    overtime_hours = Column(Float)
    holiday_hours= Column(Float)
    gross_pay = Column(Float, nullable=False)
    
    employee_id = Column(Integer, ForeignKey('employees.id'))
    employee = relationship("Employee", back_populates="paychecks")

Base.metadata.create_all(engine)
# Utility Funcions
def get_user_by_email(email):
    return session.query(Employee).filter_by(email=email).first()

def confirm_action(prompt:str)-> bool:
    return input(f"{prompt} (yes/no: )").strip().lower() == 'yes'


# Menu dictionary
Choice = {
    1: "Add employee",
    2: "View All Employees",
    3: "Search Employee",
    4: "Remove Employee",
    5: "Modify Employee",
    6: "Calculate Paychecks",
    7: "View All Paychecks",
    8: "Exit"
}

# CRUD OPs

def add_employee():
    fName, lName, pay, email = employee_functions.emp_variables()

    # Check if the email already exists
    existing_emp = get_user_by_email(email)
    if existing_emp:
        print()  
        print("An employee with this email already exists:")
        print("-" * 60)
        print(f"ID: {existing_emp.id}  |  First Name: {existing_emp.fName}  |  "
              f"Last Name: {existing_emp.lName}  |  Pay: {existing_emp.pay:.2f}  |  Email: {existing_emp.email}")
        print("-" * 60)

        # Ask if user wants to modify
        choice = input("Do you want to modify this employee instead? (yes/no): ").strip().lower()
        if choice == "yes":
            modify_employee(existing_emp.id)  # pass employee ID
        else:
            print("Returning to main menu.")
        return  # exit the add function

    # If email does not exist, create a new employee
    emp = Employee(fName=fName, lName=lName, pay=pay, email=email)
    session.add(emp)

    try:
        session.commit()
        print(f"Employee {fName} {lName} added successfully.")
    except Exception as e:
        session.rollback()
        print("Error adding employee:", e)

    return fName, lName, pay, email

def display_table():
    """Displays all employees in a formatted table."""
    print() 
    print(f"{'ID':<5}{'First Name':<20}{'Last Name':<20}{'Pay':<10}")
    print("-" * 55)
    for emp in session.query(Employee).all():
        print(f"{emp.id:<5}{emp.fName:<20}{emp.lName:<20}{emp.pay:<10.2f}")


def query_employees():
    print(f"{'First Name':<20}{'Last Name':<20}{'Pay':<10}{'Email'}")
    print("-"*60)

    for employee in session.query(Employee).all():
        print(f"{employee.fName:<20}{employee.lName:<20}{employee.pay:<10.2f}{employee.email}")


def search_employee():
    # Step 1: show the table with IDs
    display_table()

    # Step 2: prompt user for ID
    print()  
    try:
        emp_id = int(input("Enter Employee ID to search: "))
    except ValueError:
        print("Invalid ID.")
        return

    # Step 3: search by primary key
    employee = session.get(Employee, emp_id)

    if employee:
        # Step 4: display only this employee info on one line
        print() 
        print(f"{'ID':<5}{'First Name':<20}{'Last Name':<20}{'Pay':<10}")
        print("-" * 55)
        print(f"{employee.id:<5}{employee.fName:<20}{employee.lName:<20}{employee.pay:<10.2f}")
    else:
        print("Employee not found.")

def remove_employee():
    """Removes an employee by ID after confirmation."""
    # Step 1: show table
    display_table()

    # Step 2: get employee ID to remove
    print()
    try:
        emp_id = int(input("Enter Employee ID to remove: "))
    except ValueError:
        print("Invalid ID.")
        return

    employee = session.get(Employee, emp_id)
    if not employee:
        print("Employee not found.")
        return

    # Step 3: confirm deletion
    confirm = input(f"Are you sure you want to delete {employee.fName} {employee.lName}? (yes/no): ").strip().lower()
    if confirm != 'yes':
        print("Deletion cancelled.")
        return

    # Step 4: delete employee (paychecks cascade automatically)
    session.delete(employee)
    session.commit()
    print(f"Employee {employee.fName} {employee.lName} removed successfully.")

def modify_employee(emp_id=None):

    display_table()
    # If no ID passed, ask user
    if emp_id is None:
        try:
            emp_id = int(input("Enter employee ID to modify: "))
        except ValueError:
            print("Invalid ID.")
            return

    employee = session.get(Employee, emp_id)
    if not employee:
        print("Employee not found.")
        return

    # Show current info
    print("-" * 60)
    print(f"ID: {employee.id}  |  First Name: {employee.fName}  |  "
          f"Last Name: {employee.lName}  |  Pay: {employee.pay:.2f}  |  Email: {employee.email}")
    print("-" * 60)

    # Ask for new values with prefill
    new_fname = input(f"Enter new first name [{employee.fName}]: ").strip()
    if not new_fname:
        new_fname = employee.fName

    new_lname = input(f"Enter new last name [{employee.lName}]: ").strip()
    if not new_lname:
        new_lname = employee.lName

    # Email validation
    while True:
        new_email = input(f"Enter new email [{employee.email}]: ").strip()
        if not new_email:
            new_email = employee.email
        if new_email != employee.email and get_user_by_email(new_email):
            print("This email already exists. Please enter a different email.")
        else:
            break

    # Pay validation
    while True:
        new_pay_input = input(f"Enter new pay [{employee.pay:.2f}]: ").strip()
        if not new_pay_input:
            new_pay = employee.pay
            break
        try:
            new_pay = float(new_pay_input)
            break
        except ValueError:
            print("Invalid entry. Please enter a number.")

    # Confirm changes
    print("-" * 60)
    print(f"New info -> First Name: {new_fname} | Last Name: {new_lname} | Pay: {new_pay:.2f} | Email: {new_email}")
    confirm = input("Confirm changes? (yes/no): ").strip().lower()
    if confirm == "yes":
        employee.fName = new_fname
        employee.lName = new_lname
        employee.email = new_email
        employee.pay = new_pay
        session.commit()
        print("Employee updated successfully.")
    else:
        print("No changes made.")

def calculate_paycheck():
    display_table()
    print()

    try:
        emp_id = int(input("Enter Employee ID to calculate paycheck: "))
    except ValueError:
        print("Invalid ID.")
        return

    employee = session.get(Employee, emp_id)
    if not employee:
        print("Employee not found.")
        return

    PAY = 1.5

    # Step 1: Get hours worked
    hours = employee_functions.hours_variables()

    # Step 2: Calculate overtime
    overtime, overtime_pay = employee_functions.ot_pay(employee.pay, PAY, hours)

    # Step 3: Calculate holiday hours/pay
    holiday_hours, holiday_pay = employee_functions.hday_hours(PAY, employee.pay)

    # Step 4: Calculate gross pay
    gross = employee_functions.gross_pay(
        employee.pay,
        hours,
        overtime_pay,
        overtime,
        holiday_pay,
        holiday_hours
    )

    # Step 5: Save paycheck to database
    paycheck = Paycheck(
        hours=hours,
        overtime_hours=overtime,
        holiday_hours=holiday_hours,
        gross_pay=gross,
        employee=employee
    )
    session.add(paycheck)
    session.commit()

    # Step 6: Display paycheck
    print()
    print(f"{'ID':<5}{'Employee':<25}{'Hours':<10}{'Overtime':<10}{'Holiday':<10}{'Gross Pay'}")
    print("-" * 95)
    emp_name = f"{employee.fName} {employee.lName}"
    print(f"{employee.id:<5}{emp_name:<25}{hours:<10.2f}{overtime:<10.2f}{holiday_hours:<10.2f}{gross}")

def view_all_paychecks():
    paychecks = session.query(Paycheck).all()

    if not paychecks:
        print("No paychecks found.")
        return

    # Header
    print()
    print(f"{'ID':<5}{'Employee':<25}{'Hours':<10}{'Overtime':<10}{'Holiday':<10}{'Gross Pay'}")
    print("-" * 90)

    # Totals
    total_hours = 0
    total_overtime = 0
    total_holiday = 0
    total_gross = 0

    for pc in paychecks:
        emp_name = f"{pc.employee.fName} {pc.employee.lName}"
        print(f"{pc.id:<5}{emp_name:<25}{pc.hours:<10.2f}{pc.overtime_hours:<10.2f}{pc.holiday_hours:<10.2f}{pc.gross_pay}")
        
        total_hours += pc.hours
        total_overtime += pc.overtime_hours
        total_holiday += pc.holiday_hours
        total_gross += float(pc.gross_pay)

    # Totals row
    print("-" * 90)
    print(f"{'Totals':<30}{total_hours:<10.2f}{total_overtime:<10.2f}{total_holiday:<10.2f}{total_gross:.2f}")

# Main Ops
def main():
    choice = 0

    while choice != 8:
        # Display menu with top and bottom borders
        print("-" * 50)
        for key, value in Choice.items():
            print(f"{key}. {value}")
        print("-" * 50)

        # Input prompt with its own border
        while True:
            print("=" * 50)
            user_input = input("Please enter your choice: ").strip()
            print("=" * 50)

            if not user_input.isdigit():
                print("Invalid input. Please enter a number.")
            else:
                choice = int(user_input)
                if choice not in Choice:
                    print("Invalid choice. Please select a valid option.")
                else:
                    break  # Valid choice entered

        # Execute the selected option
        if choice == 1:
            add_employee()
        elif choice == 2:
            display_table()
        elif choice == 3:
            search_employee()
        elif choice == 4:
            display_table()
            remove_employee()
        elif choice == 5:
            modify_employee()
        elif choice == 6:
            calculate_paycheck()
        elif choice == 7:
            view_all_paychecks()

    print("Exiting Payroll System")

if __name__ == "__main__":        
    main()